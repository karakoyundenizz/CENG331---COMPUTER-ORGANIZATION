/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_306()
{
    return 2425393240U;
}

unsigned addval_282(unsigned x)
{
    return x + 3267791176U;
}

unsigned getval_288()
{
    return 3251646792U;
}

void setval_303(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_308(unsigned x)
{
    return x + 3330885834U;
}

void setval_396(unsigned *p)
{
    *p = 3285201224U;
}

unsigned getval_281()
{
    return 432232511U;
}

unsigned addval_226(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_381(unsigned x)
{
    return x + 2429565256U;
}

void setval_355(unsigned *p)
{
    *p = 2425379329U;
}

unsigned getval_215()
{
    return 3281147980U;
}

void setval_109(unsigned *p)
{
    *p = 2148814928U;
}

unsigned getval_472()
{
    return 2428930376U;
}

void setval_454(unsigned *p)
{
    *p = 2425445062U;
}

void setval_261(unsigned *p)
{
    *p = 1373291098U;
}

unsigned addval_486(unsigned x)
{
    return x + 3281031258U;
}

unsigned addval_273(unsigned x)
{
    return x + 3284633930U;
}

void setval_287(unsigned *p)
{
    *p = 3284568408U;
}

unsigned addval_275(unsigned x)
{
    return x + 3351742792U;
}

unsigned addval_418(unsigned x)
{
    return x + 3492890802U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_123()
{
    return 3084945736U;
}

unsigned addval_224(unsigned x)
{
    return x + 3398014261U;
}

void setval_299(unsigned *p)
{
    *p = 3599359699U;
}

unsigned addval_372(unsigned x)
{
    return x + 3503721411U;
}

void setval_232(unsigned *p)
{
    *p = 3580676737U;
}

unsigned getval_259()
{
    return 2429192494U;
}

unsigned getval_118()
{
    return 2425542281U;
}

unsigned getval_446()
{
    return 2425411208U;
}

unsigned addval_172(unsigned x)
{
    return x + 3252717896U;
}

unsigned addval_131(unsigned x)
{
    return x + 2425405832U;
}

unsigned addval_357(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_219()
{
    return 2464188744U;
}

void setval_292(unsigned *p)
{
    *p = 1036683574U;
}

unsigned getval_427()
{
    return 3286272328U;
}

unsigned getval_246()
{
    return 3286276424U;
}

void setval_407(unsigned *p)
{
    *p = 2244020671U;
}

unsigned getval_445()
{
    return 3264268937U;
}

unsigned getval_152()
{
    return 181836036U;
}

unsigned getval_333()
{
    return 2429946204U;
}

unsigned addval_174(unsigned x)
{
    return x + 918653278U;
}

unsigned addval_495(unsigned x)
{
    return x + 2429978924U;
}

unsigned addval_455(unsigned x)
{
    return x + 3250686437U;
}

void setval_280(unsigned *p)
{
    *p = 3286272320U;
}

void setval_111(unsigned *p)
{
    *p = 3682912905U;
}

unsigned getval_158()
{
    return 3281049225U;
}

unsigned addval_339(unsigned x)
{
    return x + 3523789197U;
}

unsigned addval_180(unsigned x)
{
    return x + 2308030857U;
}

void setval_351(unsigned *p)
{
    *p = 3348155017U;
}

unsigned addval_320(unsigned x)
{
    return x + 2261420453U;
}

unsigned addval_279(unsigned x)
{
    return x + 2224079241U;
}

unsigned addval_302(unsigned x)
{
    return x + 3238642090U;
}

unsigned getval_236()
{
    return 3252717896U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
